<?php
			
	class Xcsalones extends ActiveRecord {
		
	}
	
?>
