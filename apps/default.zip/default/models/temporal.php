<?php
			
	class Temporal extends ActiveRecord {
		
	}
	
?>
