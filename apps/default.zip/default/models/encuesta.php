<?php
			
	class Encuesta extends ActiveRecord {
		
	}
	
?>
