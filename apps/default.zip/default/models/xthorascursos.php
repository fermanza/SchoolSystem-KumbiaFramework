<?php
			
	class Xthorascursos extends ActiveRecord {
		
	}
	
?>
