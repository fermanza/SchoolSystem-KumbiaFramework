<?php
			
	class XcursosInfo extends ActiveRecord {
		
	}
	
?>
