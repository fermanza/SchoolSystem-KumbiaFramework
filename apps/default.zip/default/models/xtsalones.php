<?php
			
	class Xtsalones extends ActiveRecord {
		
	}
	
?>
