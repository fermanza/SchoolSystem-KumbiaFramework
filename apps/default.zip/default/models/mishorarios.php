<?php
			
	class Mishorarios extends ActiveRecord {
		
	}
	
?>
