<?php
			
	class Buscar extends ActiveRecord {

	}
	
?>
