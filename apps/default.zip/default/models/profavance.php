<?php
			
	class Profavance extends ActiveRecord {
		
	}
	
?>
