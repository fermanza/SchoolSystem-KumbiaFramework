<?php
			
	class Plantelcarrera extends ActiveRecord {
		
	}
	
?>
