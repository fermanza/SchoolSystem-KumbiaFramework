<?php			
	class CajaConceptos extends ActiveRecord {
	
        static public function reporte($registro, $tipoPersona){
		                                            
		    $Alumnos = new Alumnos();
			
			$Objeto = new cajaConceptos();
			  
			//Obtengo los datos del alumno
			if($tipoPersona == 1){
			   $alumnos = $Alumnos -> find_first('miReg ='.$registro);

			  //Si No tiene realizado el pago solo podra ver el concepto de inscripcion
			  if($alumnos -> pago == 0 && $alumnos -> condonado == 0){        	
				 $objetos = $Objeto -> find('id IN(3,16,53,5,6) ORDER BY nombre ASC');
			  }
			  
			  else{
			    $objetos = $Objeto -> find('activo = 1 AND id != 3 AND id != 16 AND id != 53 AND id != 2 AND id != 5 AND id != 6 AND (nivel = "I" OR nivel = "TI") ORDER BY nombre ASC');
			  }
			}
			
			else if($tipoPersona == 2)
		    {
			  $objetos = $Objeto -> find('id IN(19,111,93) ');
			}
			
			else if($tipoPersona == 5)
			{
			  $alumnos = $Alumnos -> find_first('miReg ='.$registro);
			  
			  if($alumnos -> pago == 0 && $alumnos -> condonado == 0 && $alumnos -> miPerIng == Session::get_data('periodo')){        	
				$objetos = $Objeto -> find('id IN(3,16,53)  ORDER BY nombre ASC');
			  }
			  
			  else if($alumnos -> stSit == "BT" || $alumnos -> stSit == "BD" ||($alumnos -> pago == 0 && $alumnos -> condonado == 0 && $alumnos -> miPerIng != Session::get_data('periodo') && $alumnos -> stSit == "OK")){        	
				$objetos = $Objeto -> find('id IN(4,5,6)  ORDER BY nombre ASC');
			  }
			  
			  else if($alumnos -> stSit == "EG")
			  {
			    $objetos = $Objeto -> find('id IN(100, 48, 109, 8, 74, 18, 98)  ORDER BY nombre ASC');
			  }
			  
			  else{
			    $objetos = $Objeto -> find('activo = 1 AND id != 3 AND id != 16 AND id != 53 AND id != 4 AND id != 5 AND id != 6 AND id != 19 AND id != 111 AND id != 93 AND (nivel = "I" OR nivel = "TI") ORDER BY nombre ASC');
			  }
			}
			
			//Obtiene los conceptos que aplican para tecnologo
			else{
			  $objetos = $Objeto -> find('activo = 1 AND id != 3 AND id != 16 AND id != 53 AND id != 4 AND id != 5 AND id != 6 AND (nivel = "I" OR nivel = "TI") ORDER BY nombre ASC');
			}
			
            return $objetos;
        }
		
		static public function conceptos($tipoPersona = ""){
		
		  $objeto = new cajaConceptos();
		  
		  if($tipoPersona == 2)
		    $objetos = $Objeto -> find('id = 20');
		}
        
		 static public function status(){
	
		    $statusSearch = "Sin busqueda";
           
		   return $statusSearch;
        }
		

		
        static public function nombre($id){
	
            $Objeto = new CajaConceptos();
            $Objeto -> find_first('id = '.$id);
			
            return $Objeto;
        }
        
        public static function registrar(){
            $Objeto = new CajaConceptos();
         
            $Objeto -> save();
            
            return $Objeto;                           
        }
        
        static public function consultar($id){
            $Objeto = new CajaConceptos();            
          
            $Objeto -> find_first('id = '.$id);
            
            return $Objeto;
        }        
        
        static public function eliminar($id){
            $Objeto = new CajaConceptos();
                        
            $Objeto -> delete($id);
            
            return $Objeto;
        }
        
	}	
?>