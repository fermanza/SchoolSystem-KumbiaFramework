<?php
			
	class Admitidos2 extends ActiveRecord {
		
	}
	
?>
