<?php
			
	class Eva12008Respuestas extends ActiveRecord {
		
	}
	
?>
