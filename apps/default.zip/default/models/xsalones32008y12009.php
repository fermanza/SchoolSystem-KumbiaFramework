<?php
			
	class Xsalones32008y12009 extends ActiveRecord {
		
	}
	
?>
