<?php
	class Xtalumnocursos extends ActiveRecord {
		
		function get_materias_semestre_actual($registro){
			$Periodos = new Periodos();
			$periodo = $Periodos->get_periodo_actual();
			
			$xalumnocursos = Array();
			foreach( $this->find_all_by_sql("
					select xal.*, xcc.clavecurso curso, xcc.clavecurso
					from xtalumnocursos xal
					inner join xtcursos xcc
					on xal.curso_id = xcc.id
					and xal.registro = '".$registro."'
					and xal.periodo = '".$periodo."'") as $xal ){
				array_push($xalumnocursos, $xal);
			}
			return $xalumnocursos;
		} // function get_materias_semestre_actual($registro)
		
		function get_materias_semestre_by_periodo($registro, $periodo){
			
			$xalumnocursos = Array();
			foreach( $this->find_all_by_sql("
					select xal.*, xcc.clavecurso curso, xcc.clavecurso
					from xtalumnocursos xal
					inner join xtcursos xcc
					on xal.curso_id = xcc.id
					and xal.registro = '".$registro."'
					and xal.periodo = '".$periodo."'") as $xal ){
				array_push($xalumnocursos, $xal);
			}
			return $xalumnocursos;
		} // function get_materias_semestre_by_periodo($registro, $periodo)
		
		function get_materia_con_baja_definitiva($registro){
			$Periodos = new Periodos();
			$periodo = $Periodos -> get_periodo_actual_();
			if( $this -> find_first("situacion = 'BAJA DEFINITIVA'".
					" and periodo = '".$periodo."'".
					" and registro = '".$registro."'") )
				return true;
			else
				return false;
		} // function get_materia_con_baja_definitiva($registro)
		
		function get_materia_con_baja_definitiva_by_periodo($registro, $periodo){
			if( $this -> find_first("situacion = 'BAJA DEFINITIVA'".
					" and periodo = '".$periodo."'".
					" and registro = '".$registro."'") )
				return true;
			else
				return false;
		} // function get_materia_con_baja_definitiva_by_periodo($registro, $periodo)
		
		function get_materias_con_baja_definitiva_o_titulo_colomos($registro){
			$Periodos = new Periodos();
			$periodo = $Periodos -> get_periodo_actual_();
			$MateriasConBajaOTitulo = Array();
			foreach( $this -> find_all_by_sql("
					select xal.*
					from xtalumnocursos xal
					where periodo = '".$periodo."'
					and registro = '".$registro."'
					and situacion = 'BAJA DEFINITIVA'") as $xal ){
				foreach( $this -> find_all_by_sql("
						select xcc.materia, m.nombre nombre_materia
						from xtcursos xcc
						inner join materia m
						on xcc.materia = m.clave
						and xcc.clavecurso = '".$xal -> curso."'
						group by xcc.id") as $xcc ){
					$BajasYTitulos -> materia = $xcc -> materia;
					$BajasYTitulos -> nombre_materia = $xcc -> nombre_materia;
					$BajasYTitulos -> calificacion = $xal -> calificacion;
					$BajasYTitulos -> situacion = $xal -> situacion;
					echo $BajasYTitulos -> clavecurso = $xal -> curso;
					array_push($MateriasConBajaOTitulo, $BajasYTitulos);
				}
			}
			foreach( $this -> find_all_by_sql("
					select xal.*
					from xtextraordinarios xal
					where periodo = '".$periodo."'
					and registro = '".$registro."'
					and tipo = 'T'
					and calificacion < 70") as $xal ){
				foreach( $this -> find_all_by_sql("
						select xcc.materia, m.nombre nombre_materia
						from xtcursos xcc
						inner join materia m
						on xcc.materia = m.clave
						and xcc.clavecurso = '".$xal -> curso."'
						group by xcc.id") as $xcc ){
					$BajasYTitulos -> materia = $xcc -> materia;
					$BajasYTitulos -> nombre_materia = $xcc -> nombre_materia;
					$BajasYTitulos -> calificacion = $xal -> calificacion;
					$BajasYTitulos -> situacion = $xal -> situacion;
					echo $BajasYTitulos -> clavecurso = $xal -> curso;
					array_push($MateriasConBajaOTitulo, $BajasYTitulos);
				}
			}
			return $MateriasConBajaOTitulo;
		} // function get_materias_con_baja_definitiva_o_titulo_colomos($registro)
		
		function get_materias_con_baja_definitiva_o_titulo_tonala($registro){
			$Periodos = new Periodos();
			$periodo = $Periodos -> get_periodo_actual_();
			$MateriasConBajaOTitulo = Array();
			foreach( $this -> find_all_by_sql("
					select xal.*
					from xtalumnocursos xal
					where periodo = '".$periodo."'
					and registro = '".$registro."'
					and situacion = 'BAJA DEFINITIVA'") as $xal ){
				foreach( $this -> find_all_by_sql("
						select xcc.materia, m.nombre nombre_materia
						from xtcursos xcc
						inner join materia m
						on xcc.materia = m.clave
						and xcc.clavecurso = '".$xal -> curso."'
						group by xcc.id") as $xcc ){
					$BajasYTitulos -> materia = $xcc -> materia;
					$BajasYTitulos -> nombre_materia = $xcc -> nombre_materia;
					$BajasYTitulos -> calificacion = $xal -> calificacion;
					$BajasYTitulos -> situacion = $xal -> situacion;
					echo $BajasYTitulos -> clavecurso = $xal -> curso;
					array_push($MateriasConBajaOTitulo, $BajasYTitulos);
				}
			}
			foreach( $this -> find_all_by_sql("
					select xal.*
					from xtextraordinarios xal
					where periodo = '".$periodo."'
					and registro = '".$registro."'
					and tipo = 'T'
					and calificacion < 70") as $xal ){
				foreach( $this -> find_all_by_sql("
						select xcc.materia, m.nombre nombre_materia
						from xtcursos xcc
						inner join materia m
						on xcc.materia = m.clave
						and xcc.clavecurso = '".$xal -> curso."'
						group by xcc.id") as $xcc ){
					$BajasYTitulos -> materia = $xcc -> materia;
					$BajasYTitulos -> nombre_materia = $xcc -> nombre_materia;
					$BajasYTitulos -> calificacion = $xal -> calificacion;
					$BajasYTitulos -> situacion = $xal -> situacion;
					echo $BajasYTitulos -> clavecurso = $xal -> curso;
					array_push($MateriasConBajaOTitulo, $BajasYTitulos);
				}
			}
			return $MateriasConBajaOTitulo;
		} // function get_materias_con_baja_definitiva_o_titulo_tonala($registro)
	}
?>
