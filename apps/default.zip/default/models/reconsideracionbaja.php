<?php
			
	class ReconsideracionBaja extends ActiveRecord {
		
	}
	
?>
