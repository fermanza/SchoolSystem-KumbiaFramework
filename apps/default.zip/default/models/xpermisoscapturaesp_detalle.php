<?php
			
	class xpermisoscapturaespDetalle extends ActiveRecord {
		
	}
	
?>
