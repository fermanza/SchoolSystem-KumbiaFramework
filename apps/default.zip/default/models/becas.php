<?php			
	class Becas extends ActiveRecord {

	}	
?>