<?php
			
	class cursosComunes extends ActiveRecord {
		
	}
	
?>