<?php			
	class BecaAlumno extends ActiveRecord {

	}	
?>