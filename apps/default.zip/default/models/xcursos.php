<?php
			
	class Xcursos extends ActiveRecord {
		
	}
	
?>
