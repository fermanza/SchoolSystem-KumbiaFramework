<?php
			
	class AutorizarCruces extends ActiveRecord {
		
	}
	
?>