<?php
			
	class XalumnosPersonal extends ActiveRecord {
		
	}
	
?>
