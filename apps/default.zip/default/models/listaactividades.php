<?php
			
	class Listaactividades extends ActiveRecord {
		
	}
	
?>
