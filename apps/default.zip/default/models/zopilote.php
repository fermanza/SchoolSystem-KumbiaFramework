<?php
			
	class Zopilote extends ActiveRecord {
		
	}
	
?>
