<?php
			
	class Configuracion extends ActiveRecord {
		
	}
	
?>