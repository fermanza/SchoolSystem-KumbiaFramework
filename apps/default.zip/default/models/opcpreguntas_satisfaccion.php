<?php
	class OpcpreguntasSatisfaccion extends ActiveRecord {

	}
?>
