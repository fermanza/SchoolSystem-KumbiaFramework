<?php			
	class HistorialAlumno extends ActiveRecord {

	}	
?>