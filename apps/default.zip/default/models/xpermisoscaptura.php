<?php
			
	class Xpermisoscaptura extends ActiveRecord {
		
	}
	
?>
