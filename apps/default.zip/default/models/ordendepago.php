<?php
			
	class Ordendepago extends ActiveRecord {

	}
	
?>
