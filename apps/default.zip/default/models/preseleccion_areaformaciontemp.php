<?php
			
	class PreseleccionAreaformaciontemp extends ActiveRecord {
		
	}
	
?>
