<?php
	class Xalumnocursos extends ActiveRecord {
	
		function get_materias_semestre_actual($registro){
			$Periodos = new Periodos();
			$periodo = $Periodos->get_periodo_actual();
			
			$xalumnocursos = Array();
			foreach( $this->find_all_by_sql("
					select xal.*, xcc.clavecurso curso, xcc.clavecurso
					from xalumnocursos xal
					inner join xccursos xcc
					on xal.curso_id = xcc.id
					and xal.registro = '".$registro."'
					and xal.periodo = '".$periodo."'") as $xal ){
				array_push($xalumnocursos, $xal);
			}
			return $xalumnocursos;
		} // function get_materias_semestre_actual($registro)
		
		function get_materias_semestre_by_periodo($registro, $periodo){
			
			$xalumnocursos = Array();
			foreach( $this->find_all_by_sql("
					select xal.*, xcc.clavecurso curso, xcc.clavecurso
					from xalumnocursos xal
					inner join xccursos xcc
					on xal.curso_id = xcc.id
					and xal.registro = '".$registro."'
					and xal.periodo = '".$periodo."'") as $xal ){
				array_push($xalumnocursos, $xal);
			}
			return $xalumnocursos;
		} // function get_materias_semestre_by_periodo($registro, $periodo)
		
		function get_materia_con_baja_definitiva($registro){
			$Periodos = new Periodos();
			$periodo = $Periodos -> get_periodo_actual_();
			if( $this -> find_first("situacion = 'BAJA DEFINITIVA'".
					" and periodo = '".$periodo."'".
					" and registro = '".$registro."'") )
				return true;
			else
				return false;
		} // function get_materia_con_baja_definitiva($registro)
		
		function get_materia_con_baja_definitiva_by_periodo($registro, $periodo){
			if( $this -> find_first("situacion = 'BAJA DEFINITIVA'".
					" and periodo = '".$periodo."'".
					" and registro = '".$registro."'") )
				return true;
			else
				return false;
		} // function get_materia_con_baja_definitiva_by_periodo($registro, $periodo)
		
		function get_materias_con_baja_definitiva_o_titulo_colomos($registro){
			$Periodos = new Periodos();
			$periodo = $Periodos -> get_periodo_actual_();
			$MateriasConBajaOTitulo = Array();
			foreach( $this -> find_all_by_sql("
					select xal.*
					from xalumnocursos xal
					where periodo = '".$periodo."'
					and registro = '".$registro."'
					and situacion = 'BAJA DEFINITIVA'") as $xal ){
				foreach( $this -> find_all_by_sql("
						select xcc.materia, m.nombre nombre_materia, xcc.clavecurso
						from xccursos xcc
						inner join materia m
						on xcc.materia = m.clave
						and xcc.id = '".$xal -> curso_id."'
						group by xcc.id") as $xcc ){
					$BajasYTitulos -> materia = $xcc -> materia;
					$BajasYTitulos -> nombre_materia = $xcc -> nombre_materia;
					$BajasYTitulos -> calificacion = $xal -> calificacion;
					$BajasYTitulos -> situacion = $xal -> situacion;
					$BajasYTitulos -> clavecurso = $xcc->clavecurso;
					array_push($MateriasConBajaOTitulo, $BajasYTitulos);
				}
			}
			foreach( $this -> find_all_by_sql("
					select xal.*
					from xextraordinarios xal
					where periodo = '".$periodo."'
					and registro = '".$registro."'
					and tipo = 'T'
					and calificacion < 70") as $xal ){
				foreach( $this -> find_all_by_sql("
						select xcc.materia, m.nombre nombre_materia, xcc.clavecurso
						from xccursos xcc
						inner join materia m
						on xcc.materia = m.clave
						and xcc.id = '".$xal -> curso_id."'
						group by xcc.id") as $xcc ){
					$BajasYTitulos -> materia = $xcc -> materia;
					$BajasYTitulos -> nombre_materia = $xcc -> nombre_materia;
					$BajasYTitulos -> calificacion = $xal -> calificacion;
					$BajasYTitulos -> situacion = $xal -> situacion;
					$BajasYTitulos -> clavecurso = $xcc -> clavecurso;
					array_push($MateriasConBajaOTitulo, $BajasYTitulos);
				}
			}
			/*
			$Xextraordinarios = new Xextraordinarios();
			foreach( $this -> find_all_by_sql("
					select xal.*
					from xalumnocursos xal
					where periodo = '".$periodo."'
					and registro = '".$registro."'
					and (situacion = 'TITULO DE SUFICIENCIA'
					or situacion = 'TITULO FALTAS')") as $xal ){
					
				if( $Xextraordinarios -> find_first(
						" registro = '".$registro."' and periodo = '".$periodo."' and".
						" curso_id = '".$xal->curso_id."' and calificacion >= 70 ".
						" and calificacion <= 100") )
					continue; // Si la encuentra, significa que ya la paso, por lo que si puede proseguir con la captura de materias.
				foreach( $this -> find_all_by_sql("
						select xcc.materia, m.nombre nombre_materia, xcc.clavecurso
						from xccursos xcc
						inner join materia m
						on xcc.materia = m.clave
						and xcc.id = '".$xal -> curso_id."'
						group by xcc.id") as $xcc ){
					$BajasYTitulos -> materia = $xcc -> materia;
					$BajasYTitulos -> nombre_materia = $xcc -> nombre_materia;
					$BajasYTitulos -> calificacion = $xal -> calificacion;
					$BajasYTitulos -> situacion = $xal -> situacion;
					$BajasYTitulos -> clavecurso = $xcc->clavecurso;
					array_push($MateriasConBajaOTitulo, $BajasYTitulos);
				}
			}
			*/
			return $MateriasConBajaOTitulo;
		} // function get_materias_con_baja_definitiva_o_titulo_colomos($registro)
		
		function get_materias_con_baja_definitiva_o_titulo_tonala($registro){
			$Periodos = new Periodos();
			$periodo = $Periodos -> get_periodo_actual_();
			$MateriasConBajaOTitulo = Array();
			foreach( $this -> find_all_by_sql("
					select xal.*
					from xtalumnocursos xal
					where periodo = '".$periodo."'
					and registro = '".$registro."'
					and situacion = 'BAJA DEFINITIVA'") as $xal ){
				foreach( $this -> find_all_by_sql("
						select xcc.materia, m.nombre nombre_materia, xcc.clavecurso
						from xtcursos xcc
						inner join materia m
						on xcc.materia = m.clave
						and xcc.id = '".$xal -> curso_id."'
						group by xcc.id") as $xcc ){
					$BajasYTitulos -> materia = $xcc -> materia;
					$BajasYTitulos -> nombre_materia = $xcc -> nombre_materia;
					$BajasYTitulos -> calificacion = $xal -> calificacion;
					$BajasYTitulos -> situacion = $xal -> situacion;
					$BajasYTitulos -> clavecurso = $xcc -> clavecurso;
					array_push($MateriasConBajaOTitulo, $BajasYTitulos);
				}
			}
			foreach( $this -> find_all_by_sql("
					select xal.*
					from xtextraordinarios xal
					where periodo = '".$periodo."'
					and registro = '".$registro."'
					and tipo = 'T'
					and calificacion < 70") as $xal ){
				foreach( $this -> find_all_by_sql("
						select xcc.materia, m.nombre nombre_materia, xcc.clavecurso
						from xtcursos xcc
						inner join materia m
						on xcc.materia = m.clave
						and xcc.id = '".$xal -> curso_id."'
						group by xcc.id") as $xcc ){
					$BajasYTitulos -> materia = $xcc -> materia;
					$BajasYTitulos -> nombre_materia = $xcc -> nombre_materia;
					$BajasYTitulos -> calificacion = $xal -> calificacion;
					$BajasYTitulos -> situacion = $xal -> situacion;
					$BajasYTitulos -> clavecurso = $xcc -> clavecurso;
					array_push($MateriasConBajaOTitulo, $BajasYTitulos);
				}
			}
			/*
			$Xtextraordinarios = new Xtextraordinarios();
			foreach( $this -> find_all_by_sql("
					select xal.*
					from xtalumnocursos xal
					where periodo = '".$periodo."'
					and registro = '".$registro."'
					and (situacion = 'TITULO DE SUFICIENCIA'
					or situacion = 'TITULO FALTAS')") as $xal ){
				if( $Xtextraordinarios -> find_first(
						" registro = '".$registro."' and periodo = '".$periodo."' and".
						" curso_id = '".$xal->curso_id."' and calificacion >= 70 ".
						" and calificacion <= 100") )
					continue; // Si la encuentra, significa que ya la paso, por lo que si puede proseguir con la captura de materias.
				foreach( $this -> find_all_by_sql("
						select xcc.materia, m.nombre nombre_materia, xcc.clavecurso
						from xtcursos xcc
						inner join materia m
						on xcc.materia = m.clave
						and xcc.id = '".$xal -> curso_id."'
						group by xcc.id") as $xcc ){
					$BajasYTitulos -> materia = $xcc -> materia;
					$BajasYTitulos -> nombre_materia = $xcc -> nombre_materia;
					$BajasYTitulos -> calificacion = $xal -> calificacion;
					$BajasYTitulos -> situacion = $xal -> situacion;
					$BajasYTitulos -> clavecurso = $xcc->clavecurso;
					array_push($MateriasConBajaOTitulo, $BajasYTitulos);
				}
			}
			*/
			return $MateriasConBajaOTitulo;
		} // function get_materias_con_baja_definitiva_o_titulo_tonala($registro)
		
		function get_if_materia_es_regularizacion_o_titulo($alumno, $clavemat){
			
			$Intersemestrales = Array();
			foreach($this->find_all_by_sql("
					select xal.situacion, xcc.clavecurso, xcc.materia, m.nombre nombre_materia, xal.calificacion
					from xalumnocursos xal
					join xccursos xcc
					on xal.curso_id = xcc.id
					join materia m
					on xcc.materia = m.clave
					and m.carrera_id = '".$alumno->carrera_id."'
					and xal.registro = '".$alumno->miReg."'
					and xcc.materia = '".$clavemat."'
					and (xal.situacion = 'REGULARIZACION DIRECTA'
					or xal.situacion = 'TITULO DE SUFICIENCIA'
					or xal.situacion = 'TITULO FALTAS')") as $Inter){
				array_push($Intersemestrales, $Inter);
			}
			
			foreach($this->find_all_by_sql("
					select xal.situacion, xcc.clavecurso, xcc.materia, m.nombre nombre_materia, xal.calificacion
					from xtalumnocursos xal
					join xtcursos xcc
					on xal.curso_id = xcc.id
					join materia m
					on xcc.materia = m.clave
					and m.carrera_id = '".$alumno->carrera_id."'
					and xal.registro = '".$alumno->miReg."'
					and xcc.materia = '".$clavemat."'
					and (xal.situacion = 'REGULARIZACION DIRECTA'
					or xal.situacion = 'TITULO DE SUFICIENCIA'
					or xal.situacion = 'TITULO FALTAS')") as $Inter){
				array_push($Intersemestrales, $Inter);
			}
			
			return $Intersemestrales;
		} // function get_if_materia_es_regularizacion_o_titulo($alumno, $clavemat)
	}
?>