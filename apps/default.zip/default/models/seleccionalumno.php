<?php
			
	class Seleccionalumno extends ActiveRecord {
		
		function get_materias_seleccionAlumno_actual($periodo, $carrera_id, $areadeformacion_id){
			$registro = Session::get_data('registro');
			
			$SeleccionAlumno = new SeleccionAlumno();
			
			$materiasActualSelecc = array();
			foreach( $SeleccionAlumno -> find_all_by_sql(
					"select sa.id, m.clave, m.nombre, sa.periodo
					From seleccionalumno sa
					inner join materia m
					on sa.clavemateria = m.clave
					and sa.periodo = ".$periodo."
					and sa.registro = ".$registro."
					and m.carrera_id = ".$carrera_id."
					and (m.serie = '".$areadeformacion_id."'
					or m.serie = '-')") as $selecc ){
				array_push($materiasActualSelecc, $selecc);
			}
			return $materiasActualSelecc;
		} // function get_materias_seleccionAlumno_actual($periodo, $carrera_id)
		
		function get_creditos_seleccionAlumno_actual($periodo, $carrera_id, $areadeformacion_id){
			$registro = Session::get_data('registro');
			
			$SeleccionAlumno = new SeleccionAlumno();
			
			foreach( $SeleccionAlumno -> find_all_by_sql(
					"select sum(creditos) as creditos
					From seleccionalumno sa
					inner join materia m
					on sa.clavemateria = m.clave
					and sa.periodo = ".$periodo."
					and sa.registro = ".$registro."
					and m.carrera_id = ".$carrera_id."
					and (m.serie = '".$areadeformacion_id."'
					or m.serie = '-')" ) as $selecc ){
				$creditos = $selecc -> creditos;
			}
			return $creditos;
		} // function get_creditos_seleccionAlumno_actual($periodo, $carrera_id)
		
	}
	
?>
