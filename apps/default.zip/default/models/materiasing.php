<?php
			
	class Materiasing extends ActiveRecord {
		
	}
	
?>
