<?php
			
	class Bajastemporales extends ActiveRecord {
		
	}
	
?>
