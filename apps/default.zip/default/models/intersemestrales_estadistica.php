<?php
			
	class IntersemestralesEstadistica extends ActiveRecord {
		
	}
	
?>
