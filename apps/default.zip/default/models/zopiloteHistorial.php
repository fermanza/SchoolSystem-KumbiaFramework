<?php
			
	class ZopiloteHistorial extends ActiveRecord {
		
	}
	
?>
