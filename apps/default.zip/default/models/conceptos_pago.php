<?php			
	class ConceptosPago extends ActiveRecord {

	}	
?>