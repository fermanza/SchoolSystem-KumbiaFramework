<?php
	class Plantel extends ActiveRecord {
		
		function get_array_plantel(){
			$array_plantel = Array();
			array_push($array_plantel, "c");
			array_push($array_plantel, "t");
			
			return $array_plantel;
		} // function get_array_plantel()
	}
?>
