<?php
			
	class Xsalones extends ActiveRecord {
		
	}
	
?>
