<?php
	class PreguntasSatisfaccion extends ActiveRecord {

	}
?>
