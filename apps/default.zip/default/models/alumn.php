<?php
			
	class Alumn extends ActiveRecord {

	}
	
?>
