<?php
			
	class Especialidades extends ActiveRecord {
		
	}
	
?>
