<?php
			
	class Xtlogcalificacion extends ActiveRecord {
		
	}
	
?>
