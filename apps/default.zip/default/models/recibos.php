<?php
			
	class Recibos extends ActiveRecord {
		
	}
	
?>
