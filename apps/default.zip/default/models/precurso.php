<?php
			
	class Precurso extends ActiveRecord {
		
	}
	
?>
