<?php
			
	class Usuarios extends ActiveRecord {
		
	}
	
?>
