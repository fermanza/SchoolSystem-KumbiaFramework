<?php
			
	class Xalumnoagenda extends ActiveRecord {
		
	}
	
?>
