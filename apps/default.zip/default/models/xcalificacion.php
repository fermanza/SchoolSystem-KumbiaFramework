<?php
			
	class Xcalificacion extends ActiveRecord {
		
	}
	
?>
