<?php
			
	class KardexIng2 extends ActiveRecord {
		
	}
	
?>
