<?php
			
	class Aspirantes extends ActiveRecord {
		
	}
	
?>