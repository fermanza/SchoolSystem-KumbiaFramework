<?php
			
	class Xalumnos extends ActiveRecord {
		
	}
	
?>
