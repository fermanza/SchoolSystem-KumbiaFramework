<?php
			
	class Registracursos extends ActiveRecord {
		
	}
	
?>
