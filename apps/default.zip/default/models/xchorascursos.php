<?php
			
	class Xchorascursos extends ActiveRecord {
		
	}
	
?>
