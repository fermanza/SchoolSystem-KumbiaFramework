<?php
			
	class Xclogmovimientosalumnocursos extends ActiveRecord {
		
	}
	
?>