<?php
			
	class VisitasSecciones extends ActiveRecord {
		
	}
	
?>
