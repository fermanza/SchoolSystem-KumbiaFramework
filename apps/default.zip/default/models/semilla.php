<?php
			
	class Semilla extends ActiveRecord {
		function getSemilla(){
			return "CtTURWX4{5}7aA";
			//return "JDKyuRF2{3a0}vmZh";
		}
	}
	
?>