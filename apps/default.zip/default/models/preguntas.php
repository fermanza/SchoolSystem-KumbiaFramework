<?php
	class Preguntas extends ActiveRecord {

	}
?>
