<?php

	class LlenarextrasController extends ApplicationController {
	
		function llenarE(){
		
		}
		
		function llenarT(){
		
		}
	
	}
?>