<?php
			
	class OrdendepagoController extends StandardForm {

		public $scaffold = true;

		public function __construct(){

		}

	}
	
?>
