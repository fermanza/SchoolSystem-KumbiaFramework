<?php

    class abrircapturaController extends ApplicationController {
		
		
		
		
		
	}
?>