<?php
/*
 *@author Ing. Carlos Adolfo Lizaola Zepeda
 *@category Kumbia
 *@package Controler   
 *GNU General Publical License v.3.0.
 */	
	class CajaController extends ApplicationController {
	
		function index(){
		  $this -> valida();  	  
		}
		
		function indexAlumno(){
		  $this -> validaAlumno();     
		}
				
		function alumnoConcepto(){
		  $this -> validaAlumno();     
		}
		
		function tramites(){
		  $this -> validaAlumno();     
		}

		function reportes(){
		  $this -> valida();     
		}
	    
		function verTramites(){
		  $this -> valida();     
		}
		
		function imprimirFichas(){
		  $this -> valida();     
		}
        
        function buscar($tipo = 'alumno'){
            $this -> set_response('view');
            $this -> tipo = $tipo;
            
            if($tipo == 'alumno'){   
			    $this -> tipoPersona = 1;
                echo $this -> render_partial('buscadorAlum'); 
            }elseif($tipo == 'aspirante'){
			    $this -> tipoPersona = 2;
                echo $this -> render_partial('buscadorAsp');
            }elseif($tipo == 'trabajador'){
			    $this -> tipoPersona = 3;
                echo $this -> render_partial('buscadorTrabajador');
            }elseif($tipo == 'otro'){
                echo $this -> render_partial('buscador');
            }else{
                Flash::error('NO SE ENCONTRO EL TIPO DE BUSQUEDA SELECCIONADA');
            }
        }
        
        function buscarXNombre(){
            $this -> set_response('view');
            $tipo = $this -> post('tipo');
            $this -> tipo = $this -> post('tipo');
			
            if($this -> post('nombre')){
                if($tipo == 'alumno'){
                    if($this -> listado = Alumnos::buscarXNombre($this -> post('nombre')))
                        echo $this -> render_partial('listado');
						
                    else
                        Flash::error('No se encontraron Resultados'); 
                }elseif($tipo == 'aspirante'){
                    Aspirantes::buscarXNombre($this -> post('nombre'));
                    echo $this -> render_partial('listado');
                }elseif($tipo == 'trabajador'){
                    Trabajadores::buscarXNombre($this -> post('nombre'));
                    echo $this -> render_partial('listado');
                }elseif($tipo == 'otro'){
                    Otros::buscarXNombre($this -> post('nombre'));
                    echo $this -> render_partial('listado');
                }else{
                    Flash::error('NO SE ENCONTRO EL TIPO DE BUSQUEDA SELECCIONADA');
                }
            }
			else{
                Flash::error('Escribe un nombre para la busqueda');
            }
        }
		 
		function periodo()
		{ 
		  $this -> set_response('view');
		  $tipo = $this -> post('tipo');
		  $this -> tipo = $this -> post('tipo');

		  if($this -> post('periodo'))
		  {
		    if($tipo == 'alumno'){
			 if($this -> listado = Alumnos::buscarXPeriodo($this -> post('periodo')))
                        echo $this -> render_partial('listado');

		      else
			    Flash::error('No se encontraron resultados');
			}
		  }
		  
		  else
		  {
		    Flash::error('Selecciona un periodo');
		  }
		}
		
		
        function llenado($tipo = '',$registro = ''){
            $this -> set_response('view');
            if($this -> has_post('tipo','registro')){
                $registro = $this -> post('registro');
                $this -> registro = $this -> post('registro');   
                $tipo = $this -> post('tipo');
            }
			
            if($registro){
                $this -> registro = $registro;
                $this -> fecha = date('d-m-Y');
                $this -> folio = (CajaPagos::ultimoFolio())+1;
                $this -> alumno = Alumnos::buscar($registro);
                $this -> sql = '';   
				
				if($this -> alumno)
                  echo $this -> render_partial('formulario');
				  
				else
				  Flash::error('No se encontro el Registro');
            }
			
			else{
                Flash::error('No se encontro el Registro');
            }
        }		
        
        function buscarConceptos(){
		  
			$Objeto = new CajaConceptos();            
           
            if($this -> post('concepto') != ''){ 
			    $this -> result = $Objeto -> find("nombre like '%".$this -> post('concepto')."%' AND (nivel = 'T' OR nivel = 'TI')");						
            }
			
			else{
                Flash::error('Es necesario ingresar el concepto que se desea buscar');
            }
			
		
            $this -> set_response('view');
		  
            echo $this -> render_partial('listadoConceptos');
        }
        
        function complementario($concepto_id=0){
		
            $this -> set_response('view');
            $this -> concepto_id = $concepto_id;
			
			$this -> render_partial('complementario');
			
           /* if($concepto_id != 3 && $concepto_id != 4){
                $this -> render_partial('complementario');
            }
			else{
                switch($concepto_id){
                    case 3: $sql = "tipo = 'E' and periodo = 32009"; 
                            break;
                    case 4: $sql = "tipo = 'T' and periodo = 32009";
                            break;
                }
                $this -> examenes = Extras::reporte($sql);
                $this -> render_partial('complementarioDetallado');
            }*/
		}
        
        function agregarPagoConcepto(){
            $this -> set_response('view');
            $this -> render_partial('nota');
        }
		
		/*
		 * Esta funcion es la encargada de guardar los conceptos solicitados
		*/
		function guardarConcepto()
		{
		
		  if($this -> post('typeP') == 2 && (strlen($this -> post('nombrePost')) == 0 || strlen($this -> post('nombrePost')) < 6)){
		     Flash::error('EL NOMBRE DEL ASPIRANTE DEBE DE SER MAYOR DE 6 CARACTERES');
			 DIE();
		  }
		 
		  if($this -> post('con') != ""){
		  
			  $cajaTramites = new CajaTramites();
			   
			  //Funcion que obtiene la fecha limite de pago
			  //$fechaLimitePago = $cajaTramites -> create_fecha_limite_pago();
			  $fechaLimitePago = "22-06-2012";
			  
			  //variable obtiene periodo
			  $periodo = Session::get_data('periodo');
		      
			  //Arreglo guarda el id de los tramites agregados
			  $idTramite = Array();
			  //Arreglo guarda los extras solicitados
			  $extras = Array();
			  //Arreglo guarda los titulos solicitados
			  $titulos = Array();
			  
			  //Se valida el registro segun el tipo de persona
			  if($this -> post('typeP') == 2)
			    $registro = "";
				
			  else if($this -> post('typeP') == 5)
			    $registro = Session::get('registro');
				
			  else
			    $registro = $this -> post('registro');
				
				
			  if($this -> post('typeP') == 5)
			    $typeP = 1;
				
			  else
			     $typeP = $this -> post('typeP');
			  
			if($this->post('extra') != ""){
			  foreach($this->post('extra') AS $valueE)  
		        $extrasInsert[] = $valueE;
			}
          
            if($this->post('titulo') != ""){		  
		      foreach($this->post('titulo') AS $valueT)  
		        $tituloInsert[] = $valueT;
			}	
				
			if($this->post('cursoNV') != ""){
		      foreach($this->post('cursoNV') AS $valueCN)  
		        $CNVInsert[] = $valueCN;
            }
			
			if($this->post('cursoAC') != ""){
		      foreach($this->post('cursoAC') AS $valueAC)  
		        $CACRInsert[] = $valueAC;
            }
			
		      //Se guardan los datos de los conceptos solicitados
			  foreach( $this->post("con") as $concepto )
			  {		
				$cajaTramites -> concepto = $concepto;
				$cajaTramites -> registro = $registro;
				$cajaTramites -> nombre_solicitante = $this -> post('nombrePost');
				$cajaTramites -> periodo =  $periodo;
				$cajaTramites -> cantidad = $this->post("cantidad".$concepto);
				$cajaTramites -> costo = $this->post("costo".$concepto);
				$cajaTramites -> monto_total = $this->post("total".$concepto);
				$cajaTramites -> fecha_tramite = date('Y-m-d H:i:s');
				$cajaTramites -> tipo_persona = $typeP;

				if($concepto != 51 && $concepto != 58 && $concepto != 94 && $concepto != 95){
                  $cajaTramites -> actas = "";
				  //Se guardan la cantidad por conceptos solicitados
				  for($x = 0; $x < $this->post("cantidad".$concepto); $x++) {
				    $cajaTramites -> create();
				    //Obtiene el ultimo id insertado
				    $idTramite[] = mysql_insert_id();
				  }
                }
				
				//Se guardan los extraordinarios
				if($concepto == 58 ){
                  for($e = 0; $e < count($extrasInsert); $e++){
                    $cajaTramites -> actas = $extrasInsert[$e];
					$cajaTramites -> create();
					//Obtiene los id de la tabla tramites
					$idTramite[] .= mysql_insert_id();
				  }
				}
				
				//Se guardan los titulo
				if($concepto == 51 ){
                  for($t = 0; $t < count($tituloInsert); $t++){
                    $cajaTramites -> actas = $tituloInsert[$t];
					$cajaTramites -> create();	
					//Obtiene los id de la tabla tramites
					$idTramite[] .= mysql_insert_id();
				  }			  
				}
				
				//Se guardan los cursos de acreditacion
				if($concepto == 94){
                  for($a = 0; $a < count($CACRInsert); $a++){
                    $cajaTramites -> actas = $CACRInsert[$a];
					$cajaTramites -> create();
					//Obtiene los id de la tabla tramites
					$idTramite[] .= mysql_insert_id();
				  }
				}
				
				//Se guardan los cursos de nivelacion
				if($concepto == 95){
                  for($n = 0; $n < count($CNVInsert); $n++){
                    $cajaTramites -> actas = $CNVInsert[$n];
					$cajaTramites -> create();
					//Obtiene los id de la tabla tramites
					$idTramite[] .= mysql_insert_id();
				  }
				}
			  }
			   echo "<div id='msgMuestra' name='msgMuestra' style='display:none; color: #FFFFFF;'>TRUE</div>";
			  //Funcion que sirve para crear el numero de referencia  
			  $referencia = $cajaTramites -> create_referencia($fechaLimitePago, $registro ,$idTramite, $typeP);
		  }
		  
		  else{
             echo "<div id='msgMuestra' name='msgMuestra' style='display:none; color: #FFFFFF;'>FALSE</div>";
			 DIE();
		  }
		  
		  DIE();
		}
		
		/*
		 * Esta funcion es la encargada de general el reporte que fue solicitado
		*/
		function crearReporte()
		{
		  $this -> set_response("view");
		  
		  $cajaTramites = new cajaTramites();
		  
		  if($this -> post('reportes') == "")
		    die();

		  //Reporte general de conceptos solicitados
		  if($this -> post('reportes') == 4){
		  
		      //Titulo de tipo de reporte
			  $this -> solicitante = "GENERAL";
			  
			  //Obtiene el total de conceptos solicitados en general
			  $this -> totalConceptos = $cajaTramites -> sum("cantidad");
			  
			  //Obtiene el monto total de los conceptos solicitados en general
			  $this -> montoTotal = $cajaTramites -> sum("monto_total");
			  
			  //Obtiene el total de conceptos solicitados a ventanilla 
			  $this -> ventanillaConcep = $cajaTramites -> get_total_conceptos_por_ventanilla();
																		 												  
	          //Obtiene el monto total de los conceptos solicitados a ventanilla
			  $this -> totalVenMonto = $cajaTramites -> get_totalMonto_conceptos_por_ventanilla();

			  
			  //Obtiene el total de conceptos solicitados a caja
			  $this -> conceptoCaja = $cajaTramites -> get_total_conceptos_por_caja();
			  											
			  //Obtiene el monto total de conceptos solicitados a caja
			  $this -> montoCajaTotal = $cajaTramites -> get_totalMonto_conceptos_por_caja();

			  
			  //Obtiene el reporte por concepto solicitado
			  $this -> conceptosGeneral = $cajaTramites -> get_reporte_conceptos_general();

		      //Vista donde se muestran los resultados
			  $this -> render_partial('obtieneReporte');
		  }
		}
		
		/*
		 * Funcion encargada de mostrar los tramites solicitados
		*/
		function muestraTramites(){

		  $this -> set_response("view");
		 
		  $cajaTramites = new CajaTramites();
		 
		  $this -> getTramites = $cajaTramites -> show_Tramites($this -> post('statusTramite'), $this -> post('statusPago'), $this -> post('tipoPersona'), $this -> post('registro'));
		 
		  //Vista donde se muestran los resultados
		  $this -> render_partial('obtenerTramites');
		}
		
		/*
		 * Funcion que se encarga de modificar el estatus del tramite
		*/
		function updateTramite($param)
		{
		  $this -> set_response("view");
		  
		  $result = explode(",",$param);
		  //Se modifica el estatus del tramite
		  $db = DbBase::raw_connect();
		  $db->query("UPDATE caja_tramites SET status_tramite = ".$result[0]." WHERE id = ".$result[1]."");
		 
		  //Vista donde se muestran los resultados
		  $this -> render_partial('obtenerTramites');
		}
		
		/*
		 * Funcion que busca las fichas de pago de los conceptos solo las que se encuentran en estado de sin pagar
		*/
		function imprimeFichas()
		{
		  $this -> set_response("view");
		  
		  $cajaTramites = new CajaTramites();
		  
		  $this -> getFichas = $cajaTramites -> show_Fichas($this -> post('registro'), $this -> post('nombre'), $this -> pos('typePerson'), $this -> pos('apellidoP'), $this -> pos('apellidoM'));
		  
		  //Vista donde se muestran los resultados
		  $this -> render_partial('obtieneFichas');
		}
		
		/*
		* Funcio que trae los datos del alumno
		*/
		static function get_info_for_partial_info_alumno(){
		
			$alumnos = new Alumnos();
			$KardexIng = new KardexIng();
			
			
		    $alumno = $alumnos->find_first("miReg=".Session::get('registro'));
	
	
			// Nombre carrera
			$career = $alumnos->get_careername_from_student($alumno->carrera_id, $alumno->areadeformacion_id);
		
			// Nombre Plantel
			$plantel = $alumnos->get_nombre_plantel($alumno->enPlantel);
			// Turno Matutino o Vespertino
			$turno = $alumnos->get_turno($alumno->enTurno);
			// Obtener Creditos
		    $ncreditos = $KardexIng->get_creditos(Session::get('registro'),$alumno->carrera_id,$alumno->areadeformacion_id);
			// Obtener promedio
			$promedio = $KardexIng->get_average_from_kardex(Session::get('registro'));
		
			
			return $array = array(
						    "career" => $career->nombre,
							"plantel" => $plantel,
							"turno" => $turno,
							"ncreditos" => $ncreditos,
							"promedio" => $promedio,
							"enTipo" => $alumno -> enTipo,
							"vcNomAlu" => $alumno -> vcNomAlu,
							"miReg" => $alumno -> miReg,
					      );


		} // function get_info_for_partial_info_alumno($alumno)
		
		/*
		 * Funcion que obtiene los extras de los alumnos
		*/
		function extrasAlumno(){
		  $this -> set_response("view");
		  
		  $tipo = "E";
		  
		  $xextraordinarios	= new Xextraordinarios();
          $CajaConceptos = new CajaConceptos();   
		  
          //Obtiene el plantel del alumno		  
		  $plantel = $xextraordinarios -> get_plantel(Session::get('registro'));
			
		  //Se obtiene el total de materias que cursa un alumno
		  $totalMaterias = $xextraordinarios -> cantidad_cursos_alumno(Session::get('registro'),Session::get_data('periodo'), $plantel);
		  
		  //Se obtiene las materias que tiene el alumno como regularizacion
		  $materiasRegularizacion = $xextraordinarios -> cantidad_cursos_en_regularizacion(Session::get('registro'),Session::get_data('periodo'),$plantel);
		  
		  //Se obtiene el porcentaje de las materias en regularizacion
		  $porcenRegularizacion = $xextraordinarios -> obtiene_porcentaje($totalMaterias);
		  
		  //Se obtiene las materias que tiene el alumno como BAJA DEFINITIVA
		  $materiasBD = $xextraordinarios -> cantidad_cursos_en_BD(Session::get('registro'),Session::get_data('periodo'),$plantel);
		// var_dump($porcenRegularizacion, $materiasRegularizacion); die();
		  //No se encontraron extraordinarios a pagar
	      if($materiasBD >= 1)
		     $this -> msg = "No tienes derecho a extraordinarios estas dado de baja";
		  
		  else if(floor($porcenRegularizacion) <= $materiasRegularizacion)
		     $this -> msg = "No tienes derecho a extraordinarios";
			  
		  else
		  {
		    //Se obtiene los extraordinarios de un alumno
		    $this -> extras = $xextraordinarios -> get_extrasTitulos_alumno(Session::get('registro'),Session::get_data('periodo'),$plantel,$tipo);
			
			  if(count($this -> extras) == 0 )
			    $this -> msg = "No se encontraron extraordinarios a pagar";
				
			  else
			    $this -> msg = "0";
		  }

          //Obtiene el costo del extraordinario
          $this -> concepto = $CajaConceptos->find_first("id = 58");	

		  //Vista donde se muestran los resultados
		  $this -> render_partial('ventanaExtras');
		}
		
		function titulosAlumno(){
		  $this -> set_response("view");
		  
		  $xextraordinarios	= new Xextraordinarios();
          $CajaConceptos = new CajaConceptos();   
		  
		  $tipo = "T";
		  
          //Obtiene el plantel del alumno		  
		  $plantel = $xextraordinarios -> get_plantel(Session::get('registro'));
			
		  //Se obtiene el total de materias que cursa un alumno
		  $totalMaterias = $xextraordinarios -> cantidad_cursos_alumno(Session::get('registro'),Session::get_data('periodo'), $plantel);
		  
		  //Se obtiene las materias que tiene el alumno como regularizacion
		  $materiasRegularizacion = $xextraordinarios -> cantidad_cursos_en_regularizacion(Session::get('registro'),Session::get_data('periodo'),$plantel);
		  
		  //Se obtiene el porcentaje de las materias en regularizacion
		  $porcenRegularizacion = $xextraordinarios -> obtiene_porcentaje($totalMaterias);
		  
		  //Se obtiene las materias que tiene el alumno como BAJA DEFINITIVA
		  $materiasBD = $xextraordinarios -> cantidad_cursos_en_BD(Session::get('registro'),Session::get_data('periodo'),$plantel);
		 
		  //No se encontraron titulos a pagar
	      if($materiasBD >= 1)
		     $this -> msg = "No tienes derecho a t&iacute;tulos estas dado de baja";
		  
		  else if(floor($porcenRegularizacion) <= $materiasRegularizacion)
		     $this -> msg = "No tienes derecho a t&iacute;tulos";
			  
		  else
		  {
		    //Se obtiene los titulos de un alumno
		    $this -> titulos = $xextraordinarios -> get_extrasTitulos_alumno(Session::get('registro'),Session::get_data('periodo'),$plantel,$tipo);
			
			  if(count($this -> titulos) == 0 )
			    $this -> msg = "No se encontraron t&iacute;tulos a pagar";
				
			  else
			    $this -> msg = "0";
		  }

          //Obtiene el costo del extraordinario
          $this -> concepto = $CajaConceptos->find_first("id = 51");	

		  //Vista donde se muestran los resultados
		  $this -> render_partial('ventanaTitulos');
		}
		
		/*
		 * Funcion que obtiene los cursos de nivelacion de los alumnos
		*/
		function cursosNIVAlumno(){
		
          $this -> set_response("view");
		  
		  $xextraordinarios	= new Xextraordinarios();
		  $CajaConceptos = new CajaConceptos();
		  
		  //Tipo de curso
		  $tipoCurso = "NIV";
		  //Periodo INtersemestral
		  $periodoInter = (Session::get_data('periodo')) + (10000);

		  $this -> cursoNiv = $xextraordinarios -> get_cursos_NIV_ACR(Session::get('registro'),$periodoInter,$tipoCurso);
		  
		  if(count($this -> cursoNiv) == 0 )
			       $this -> msg = "No se encontraron cursos de nivelacion a pagar";
		
          else
 		    $this -> msg = "0";
		  
		  //Obtiene el costo del curso de nivelacion
          $this -> concepto = $CajaConceptos->find_first("id = 95");
		  
		  //Vista donde se muestran los resultados
		  $this -> render_partial('ventanaCursosNIV');
		}
		
		/*
		 * Funcion que obtiene los cursos de acreditacion de los alumnos
		*/
		function cursosACRAlumno(){
          $this -> set_response("view");
		  
		  $xextraordinarios	= new Xextraordinarios();
		  $CajaConceptos = new CajaConceptos();
		  
		  //Tipo de curso
		  $tipoCurso = "ACR";
		  //Periodo INtersemestral
		  $periodoInter = (Session::get_data('periodo')) + (10000);
		  
		  $this -> cursoAcred = $xextraordinarios -> get_cursos_NIV_ACR(Session::get('registro'),$periodoInter,$tipoCurso);
		
		  if(count($this -> cursoAcred) == 0 )
			       $this -> msg = "No se encontraron cursos de acreditacion a pagar";
				
          else
 		    $this -> msg = "0";
				   
		  //Obtiene el costo del curso de nivelacion
          $this -> concepto = $CajaConceptos->find_first("id = 94");
		  
		  //Vista donde se muestran los resultados
		  $this -> render_partial('ventanaCursosACR');
		}
		
		function valida()
		{
		  if(Session::get("tipousuario") == "VENTANILLA"){
			return true;
		  }
		
		  else{
                $this -> redirect("general/inicio");
				return true;
			}
		}
		
		function validaAlumno()
		{
		  if(Session::get("tipousuario" ) == "ALUMNO"){
			return true;
		  }
		
		  else{
                $this -> redirect("general/inicio");
				return true;
			}
		}

	} 
	
?>

                          