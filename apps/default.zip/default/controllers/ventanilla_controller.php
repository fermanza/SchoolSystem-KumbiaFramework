<?php
			
	class VentanillaController extends ApplicationController {
		
		public $anterior	= 12010;
		public $actual		= 32010;
		public $proximo		= 12011;
		
		function index(){
			
		}

		function aspirantes(){
			
		}
		
		function calificaciones(){
			
		}
		
		function calificacionesPDF(){
			
		}
		
		function calificacionesEXEL(){
			$this -> Alumno = new Alumnos();						
			$Calificaciones = new Calificaciones();
			
			$registro = $this -> post('registro');
			$this -> periodo = $periodo = $this -> post('periodo');
			
			if($this -> Alumno -> find_first('registro = '.$registro)){
				if($this -> calificaciones = $Calificaciones -> find("periodo = ".$periodo." and registro = ".$registro)){
					$this -> set_response('view');
					$this -> render_partial('calificaciones');
				}else{
					Flash::error('<h2>No se encontraron calificaciones para el registro: '.$registro.', y el periodo: '.$periodo.'</h2>');
				}				
			}else{				
				Flash::error('<h2>No se encontro el alumnos</h2>');
			}
			
			
		}
		
		function checarEstado(){
		
		}
		
		function checarEstado2(){
			
			$periodo = 32009;
			
			$alumnos = new Alumnos();						
			$xalumnocursos = new Xalumnocursos();
			
			$registro = $this -> post("registro");
			
//			$alumno = $alumnos -> find_first( "miReg = ".$registro );
			
			if ( $alumnos -> find_first( "miReg = ".$registro ) )
				echo "<br />El Alumno est� inscrito en los siguientes cursos ";
			else{
				echo "No se encontro el alumno: ".$registro;
				exit(1);
			}
			
			foreach ( $xalumnocursos -> find ( "registro = ".$registro." 
					and periodo = ".$periodo ) as $xalumncursos ){
				echo $xalumncursos -> curso."<br />";
			}
		}
		
		function checarContra(){
			
			if ( Session::get_data('tipousuario') != "VENTANILLA" ){
				$this -> redirect("general/inicio");
			}
		} //checarContra
		
		function checarContra2(){
			
			if ( Session::get_data('tipousuario') != "VENTANILLA" ){
				$this -> redirect("general/inicio");
			}
			
			$registro = $this -> post("registro");
			$usuarios	= new Usuarios();
			$semilla	= new Semilla();
			
			$this -> usuarioo = null;
			
			foreach( $usuarios -> find_all_by_sql( 
				"select AES_DECRYPT(clave,'".$semilla -> getSemilla()."') as clave, registro
				from usuarios
				where registro = '".$registro."'
				and categoria = 1" ) as $usuario ){
				$this -> usuarioo = $usuario;
			}
		} // checarContra2

        function resetearcontrasena(){

            $usuarios	= new Usuarios();
            $alumnos	= new Alumnos();

            if(Session::get_data('tipousuario')!="VENTANILLA"){
                    $this->redirect('general/inicio');
            }
            $id = $this -> post("registro");
			
            // Eliminar las variables que van a pertenecer a este m�todo.
            unset( $this -> usuario );
            unset( $this -> exito );

            $this -> exito = 0;
			$semilla = new Semilla();
            foreach( $usuarios -> find_all_by_sql( "
					update usuarios
					set clave = AES_ENCRYPT('".$id."','".$semilla -> getSemilla()."')
					where registro = '".$id."'" ) as $usuario ){
				$this -> exito = 1;
				break;
            }
			$semilla = new Semilla();
			foreach( $usuarios -> find_all_by_sql( 
					"select AES_DECRYPT(clave,'".$semilla -> getSemilla()."') as clave
					from usuarios
					where registro = '".$id."'" ) as $usuario ){
				$this -> usuario = $usuario;
			}
			
			$this -> redirect("ventanilla/checarContra");
        } // function resetearcontrasena()
		
	}
	
?>
