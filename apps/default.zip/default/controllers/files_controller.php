<?php
			
	class FilesController extends StandardForm {

		public $scaffold = true;

		public function __construct(){

		}

	}
	
?>
