<?php

	class OrdinariosakardexController extends ApplicationController {
	
		function llenarKardexIng(){
		
		}
	
	}
?>