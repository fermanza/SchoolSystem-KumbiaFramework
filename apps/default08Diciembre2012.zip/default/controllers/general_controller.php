<?php
			
	class GeneralController extends ApplicationController {

		function index(){
			echo mktime(14,0,0,10,1,2008);
		}
		
		function password($registro){
			$usuarios = new Usuarios();
			
			$usuario = $usuarios -> find_first("registro='".$registro."'");
			
			echo $usuario -> clave;
		}
		
		function fecha($d,$m,$y,$h,$i){
			echo mktime($h,$i,0,$m,$d,$y);
		}
		
		function aspirantes(){

		}
		
		function calendario(){

		}
		
		function accesourl(){
		
		}
		
		function reglamentos(){

		}
		
		function carreras(){

		}
		
		function ficha(){

		}

		function descargas(){

		}
		
		function contactanos(){

		}
		
		function inicio(){
			$this -> set_response("view");
		}
		
		function inicionuevo(){

		}
		
		function web(){
			$this -> set_response("view");
		}
		
		function crearAnuncios(){
			
		}
		
		function crearAnuncios2(){
			
		}
		
		function pago(){
			echo "<br><br>";
				echo "<H2>ACCESO RESTRINGIDO</H2>";
				
				echo "<br>";
				echo "<table><tr><td width=\"500\" align=\"center\"><h3>PAGO NO REGISTRADO</h3><br><br>
				PARA SOLUCIONAR ESTE PROBLEMA PRESENTA UNA COPIA DE TU FICHA DE PAGO EN EL DEPARTAMENTO DE APOYO ACADEMICO</td></tr></table>";
			echo "<br><br>";
		} // function pago()
		
		function acudir_calculo(){
			switch(Session::get_data("alumnos_problema")){
				case "KARDEX":
						echo "<br><br>";
							echo "<H2>ACCESO RESTRINGIDO</H2>";
							
							echo "<br>";
							echo "<table><tr><td width=\"500\" align=\"center\"><h3>Problemas con su Kardex</h3>";
							echo "<br><br>PARA SOLUCIONAR ESTE PROBLEMA FAVOR DE ACUDIR A APOYO ACAD�MICO<br />";
							echo "HORARIO DE 8:00AM A 4:00PM</td></tr></table>";
						echo "<br><br>";
					break;
				case "PAGO":
						echo "<br><br>";
							echo "<H2>ACCESO RESTRINGIDO</H2>";
							
							echo "<br>";
							echo "<table><tr><td width=\"500\" align=\"center\"><h3>Problemas de Pago</h3>";
							echo "<br><br>Tu sistema ha sido bloqueada por problemas con tu pago, 
								favor de acudir con Alicia o Aldo a Control Escolar<br />";
							echo "<br />HORARIO DE 9:00AM A 8:00PM</td></tr></table>";
						echo "<br><br>";
					break;
					case "EXTRANJERO":
						echo "<br><br>";
							echo "<H2>ACCESO RESTRINGIDO</H2>";
							
							echo "<br>";
							echo "<table><tr><td width=\"500\" align=\"center\"><h3>Actualizaci�n de informaci�n</h3>";
							echo "<br><br>Tu sistema ha sido bloqueado por cuestiones administrativas ya que estamos actualizando informacion<br>
							 y nos gustaria revisar tus datos de nacionalidad, te sugerimos que por favor<br>
								te dirigas con la Lic. Claudia Lara a Trabajo Social a un costado de Enfermer�a<br />";
							echo "<br />HORARIO DE 10:00 a 17:00 hrs.</td></tr></table>";
						echo "<br><br>";
					break;
			}
		} // acudir_calculo
		
		function sistema_no_disponible(){
			echo "<br><br>";
				echo "<h2>ACCESO RESTRINGIDO</h2>";
				
				echo "<br>";
				echo "<table><tr><td width=\"500\" align=\"center\"><h3>";
				echo "<br /><br />POR EL MOMENTO EL SISTEMA NO ESTA DISPONIBLE PARA ALUMNOS.<br />";
				echo "FAVOR DE REVISAR NUEVAMENTE APARTIR DEL 01 DE NOVIEMBRE DEL 2012.</h3></td></tr></table>";
			echo "<br><br>";
		} // sistema_no_disponible
		
		function baja(){
			echo "<br><br>";
				echo "<H2>ACCESO RESTRINGIDO</H2>";
				
				echo "<br>";
				echo "<table><tr><td width=\"500\" align=\"center\"><h3>BAJA DEFINITIVA</h3>
				<br><br>PARA SOLUCIONAR ESTE PROBLEMA PRESENTATE EN EL DEPARTAMENTO DE APOYO ACADEMICO</td></tr></table>";
			echo "<br><br>";
		}
	}
	
?>
