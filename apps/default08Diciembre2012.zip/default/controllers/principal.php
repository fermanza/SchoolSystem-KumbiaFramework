<script language="javascript">
	location.href='general/ficha';
</script>