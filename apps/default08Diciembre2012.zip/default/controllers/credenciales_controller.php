<?php
class credencialesController extends ApplicationController {

  //Funcion que muestra el index
  function index(){
	$this -> valida();  	  
  }
  
  //Funcion que muestra la pantalla para imprimir las credenciales
  function imprimirProvicional(){
    $this -> valida();     
  }
  
  //Funcion que muestra la pantalla para Actualizar Datos
  function actualizarDatos(){
    $this -> valida();
  }
  
  //Funcion que muestra la pantalla para crear el reporte
  function generarReporte(){
    $this -> valida();
	
	//Se vacian los registros de la tabla temporal
	$registrosTemp = new registrosTemp();
	$result = $registrosTemp -> truncate_registrosTemp();
	
  }
  
  //funcion que busca a un alumno por registro oara imprimir la credencial provisional
  function buscarAlumno(){	   
    $this -> set_response("view");
		   
	if($this -> post('registro') == "" || count($this -> post('registro')) == 0){
	  //Mensaje de error
	  echo '<input type="hidden" id="status" name="status" readonly="readonly" value="FALSE" maxlength="0"/>';
	  echo '<input type="hidden" id="msg" name="msg" readonly="readonly" value="Es necesario ingresar un registro" maxlength="0"/>';
	  $this -> result = "";
	}
			
	else{
	  $objeto = new alumnos(); 
	  $this -> result = $objeto -> buscar_registro_alumno($this -> post('registro'));
	  $this -> render_partial('muestraAlumnos');
	}
  }
	
	
  //Funcion que imprime en PDF la credencial provicional
  function imprimir_credencial_PDF($registro){
    $this -> set_response("view");
		  
	//Se obtienen los datos del alumno
	$objeto = new alumnos();
	$result = $objeto -> buscar_registro_alumno($registro);
		  
	foreach($result AS $value){
	  $registroAl = $value -> registro;
	  $nombre = $value -> nombres;
	  $apellidoP = $value -> a_paterno;
	  $apellidoM = $value -> a_materno;
	  $carrera = $value -> carrera;
	  $telefono = $value -> telefono;
	  $celular = $value -> celular;
	  $direccion = $value -> direccion;
	}
	
    //Se obtienen la fecha de vigencia
	$vigenciaCreden = new Credenciales();
	$fechaVigencia = $vigenciaCreden -> dias_restantes();
		  
	//Se inicia la creacion del PDF
	$pdf = new FPDF();
	$pdf -> Open();
	$pdf -> AddFont('Verdana','','verdana.php');
	$pdf -> AddPage();
		  
	//Se crea el frente de la credencial
	$pdf -> Image('public/img/CETI_n.jpg', 73,7,25,33);
	$pdf -> Rect(5,5,97,55);
    //Valida si existe existe la imagen
	if(file_exists("/var/www/htdocs/calculo/ingenieria/public/img/fotos/".$registro.".jpg"))
	  $pdf -> Image('public/img/fotos/'.$registro.".jpg", 7,7,27,30);
  
	if(file_exists("/var/www/htdocs/calculo/ingenieria/public/img/fotos/".$registro.".JPG"))
	  $pdf -> Image('public/img/fotos/'.$registro.".JPG", 7,7,27,30);

	if(file_exists("/var/www/htdocs/calculo/ingenieria/public/img/fotos/".$registro.".jpg") == false && file_exists("/var/www/htdocs/calculo/ingenieria/public/img/fotos/".$registro.".JPG") == false)
	  $pdf -> Rect(7,7,27,30);
          
		  
	/*$pdf->SetXY(32,7);
	$pdf->SetFont('Arial', 'B', 10);
	$pdf->Cell(68, 3, "SEP", 0, 0,"C");
	$pdf->SetXY(32,12);
	$pdf->SetFont('Arial', 'B', 12);
	$pdf->Cell(68, 3, "Centro de Ense�anza", 0, 0,"C");
	$pdf->SetXY(32,18);
	$pdf->SetFont('Arial', 'B', 12);
	$pdf->Cell(68, 3, " Tecnica Industrial", 0, 0,"C");
	$pdf->SetXY(32,29);
	$pdf->SetFont('Arial', 'B', 12);
	$pdf->Cell(68, 3, "Plantel Colomos", 0, 0,"C");*/

    $pdf->SetFont('Arial', '', 9);
	$pdf->SetXY(6,42);
	$pdf->Cell(16, 3,"Registro : ", 0, 0,"R");
	$pdf->SetXY(20,42);
	$pdf->Cell(82, 3,$registroAl, 0, 0,"L");
	$pdf->SetFont('Arial','B',6);
	$pdf->SetXY(75,40);
	$pdf->Cell(22,2,"PLANTEL COLOMOS", 0, 0,"C");
	$pdf->SetFont('Arial','',9);
	$pdf->SetXY(6,47);
	$pdf->Cell(16, 3,"Nombre : ", 0, 0,"R");
	$pdf->SetXY(20,47);
	$pdf->Cell(82, 3,$nombre." ".$apellidoP." ".$apellidoM, 0, 0,"L");
	$pdf->SetXY(6,52);
	$pdf->Cell(16, 3,"Carrera : ", 0, 0,"R");
	$pdf->SetXY(20,52);
	 $pdf->SetFont('Arial', '', 8.3);
	$pdf->Cell(82, 3,$carrera, 0, 0,"L");
		 
    //Se crea la parte de atras de la credencial
    $pdf -> Rect(5,60,97,55);
	$pdf->SetFont('Arial', '', 9);
	
	$pdf->SetXY(6,65);
	$pdf->Cell(16, 3,"Tel�fono : ", 0, 0,"R");
	if ($telefono==""){
	$pdf->SetXY(20,65);
	$pdf->Cell(82, 3,$celular, 0, 0,"L");
	}else{
	$pdf->SetXY(20,65);
	$pdf->Cell(82, 3,$telefono, 0, 0,"L");
	}
	$pdf->SetXY(6,70);
	$pdf->Cell(16, 3,"Domicilio : ", 0, 0,"R");
	$pdf->SetXY(20,70);
	$pdf->Cell(82, 3,$direccion, 0, 0,"L");
	$pdf->SetXY(6,80);
	$pdf->SetFont('Arial', 'B', 10);
	$pdf->Cell(38, 3,'Vigencia : ', 0, 0,"R");
	$pdf->SetXY(42,80);
	$pdf->SetFont('Arial', '', 11);
	$pdf->Cell(44, 3,$fechaVigencia." - ".date("Y"), 0, 0,"C");
	$pdf->SetXY(5,87);
	$pdf->SetFont('Arial', 'B', 14);
	$pdf->Cell(97, 3,'P R O V I S I O N A L', 0, 0,"C");
	$pdf -> line(25,103,82,103);
	//$pdf -> line(56,107,99,107);
	$pdf->SetXY(5,105);
	$pdf->SetFont('Arial', '', 6);
	$pdf->Cell(97, 3,"ING. SALVADOR TRINIDAD P�REZ", 0, 0,"C");
	$pdf->SetXY(5,108);
	$pdf->Cell(97, 3,"JEFE DEL DEPTO. DE SERVICIOS DE APOYO ACADEMICO", 0, 0,"C");
	//$pdf->SetXY(5,114);
	//$pdf->Cell(97, 3,"DE APOYO ACADEMICO", 0, 0,"C");
	//$pdf->SetXY(56,108);
	//$pdf->Cell(43, 3,"ALUMNO", 0, 0,"C");
		  
	$pdf -> Output("public/files/pdfs/Credencial.pdf","F"); 
	$this->redirect("files/pdfs/Credencial.pdf");
		  
	$this -> render_partial('muestraAlumnos');
  }
	
	
  //funcion que busca a un alumno por registro oara imprimir la credencial provisional
  function buscarAlumnoInfo(){	   
    $this -> set_response("view");
		   
	if($this -> post('registro') == "" || count($this -> post('registro')) == 0){
	  //Mensaje de error
	  echo '<input type="hidden" id="status" name="status" readonly="readonly" value="FALSE" maxlength="0"/>';
	  echo '<input type="hidden" id="msg" name="msg" readonly="readonly" value="Es necesario ingresar un registro" maxlength="0"/>';
	  $this -> result = "";
	}
			
	else{
	  $objeto = new alumnos(); 
	  $this -> result = $objeto -> buscar_registro_alumno($this -> post('registro'));
	  $this -> registroB = $this -> post('registro');
	  $this -> render_partial('actualizarDatos');
	}
  }
  
  //Funcion que modifica los datos del alumno
  function updateDatosAlumno(){
    $this -> set_response("view");
	
	$Alumnos = new XalumnosPersonal();
	
	$Alumnos -> find_first('registro = '.$this -> post('registroAlumno'));
	$Alumnos -> direccion = utf8_decode($this -> post('direccion','upper'));
	$Alumnos -> colonia = utf8_decode($this -> post('colonia','upper'));
	$Alumnos -> cp = utf8_decode($this -> post('cp','upper'));			
	$Alumnos -> curp = utf8_decode($this -> post('curp','upper'));
	$Alumnos -> telefono = $this -> post('telefono');
	$Alumnos -> celular = $this -> post('celular');
	$Alumnos -> sangre = $this -> post('sangre');
	$Alumnos -> hid = $this -> post('hid','upper');

	if($Alumnos -> update()){
	  echo "<script type='text/javascript'> showDialog('MENSAJE','Tu Informaci&oacute;n ha sido actualizada correctamente','success',4); </script>";
	  $objeto = new alumnos(); 
	  $this -> result = $objeto -> buscar_registro_alumno($this -> post('registroAlumno'));
	  $this -> registroB = $this -> post('registroAlumno');
	}
	else{
	  echo "<script type='text/javascript'> showDialog('ALERTA','Tu Informaci&oacute;n no ha podido ser actualizada','warning',4); </script>";
	}
	
	$this -> render_partial('actualizarDatos');
  }
  
  
  //funcion que busca a un alumno por registro para generar un reporte
  function buscarAlumnoReporte(){	   
    $this -> set_response("view");
		   
	if($this -> post('registro') == "" || count($this -> post('registro')) == 0){
	  //Mensaje de error
	  echo '<input type="hidden" id="status" name="status" readonly="readonly" value="FALSE" maxlength="0"/>';
	  echo '<input type="hidden" id="msg" name="msg" readonly="readonly" value="Es necesario ingresar un registro" maxlength="0"/>';
	  $this -> result = "";
	  $this -> render_partial('generarReporte');
	}
			
	else{
	  $objeto = new alumnos(); 
	  $this -> result = $objeto -> buscar_registro_alumno($this -> post('registro'));
	  
	  if(count($this -> result) <= 0 || $this -> result == ""){
	    echo "<script type='text/javascript'> showDialog('ALERTA','No se encontro el registro ".$this -> post('registro')."','warning',4); </script>";
	    $this -> result = "";
		$this -> registroB = $this -> post('registro');
	    $this -> render_partial('generarReporte');
	  }
	  else{
	    $this -> registroB = $this -> post('registro');
	    $this -> render_partial('generarReporte');
	  }
	}
  }
  
  
  //Funcion que exporta el la lista (reporte) en excel
  function reporteExcel(){
  
    $this -> set_response("view");
	
	$this -> valida();
	
	$registrosTemp = new registrosTemp();

	$result = $registrosTemp -> get_registros();

	$this -> registros = $result ;

	$this -> render_partial('reporteExcel');
  }
  
  //Funcion que sirve para guardar o eliminar los reistros temporalmente en una tabla
  function agregar_registros(){
	$this -> set_response("view");
	
	$registrosTemp = new registrosTemp();
    //Se guardan los registros
	if($_GET['tipoAccion'] == 1){
	  $registrosTemp -> registro = $_GET['registro'];
	  $registrosTemp -> tipo = "1";
	  
	  $registrosTemp -> save();
	}
	
	//Se eliminan los registros
	if($_GET['tipoAccion'] == 2){  
      $db = DbBase::raw_connect();
	  $db->query("DELETE FROM registros_temp WHERE registro = ".$_GET['registro']);
	}
	
	 $this -> render_partial('generarReporte');
  }
  
  
  //Funcion que valida el acceso al modulo   
  function valida()
  {
	if(Session::get('registro') == "1861" || Session::get('registro') == "2551" || Session::get('registro') == "alonso"  || Session::get('registro') == "2717"){
	  return true;
	}
		
	else{
      $this -> redirect("general/ingresar");
		return true;
	}
  }
	
}
 	
?>

                          