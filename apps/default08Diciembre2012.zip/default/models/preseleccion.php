<?php			
	class Preseleccion extends ActiveRecord {

	}	
?>