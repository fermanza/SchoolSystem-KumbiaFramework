<?php
	class RespuestasSatisfaccion extends ActiveRecord {

	}
?>
