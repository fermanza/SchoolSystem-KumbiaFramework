<?php
			
	class Horarios extends ActiveRecord {
		
	}
	
?>
