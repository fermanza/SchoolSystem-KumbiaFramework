<?php
			
	class Globales extends ActiveRecord {
		
	}
	
?>
