<?php
			
	class Banderas extends ActiveRecord {
		
	}
	
?>
