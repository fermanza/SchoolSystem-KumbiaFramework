<?php
			
	class Files extends ActiveRecord {

	}
	
?>
