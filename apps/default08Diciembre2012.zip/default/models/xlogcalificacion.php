<?php
			
	class Xlogcalificacion extends ActiveRecord {
		
	}
	
?>
