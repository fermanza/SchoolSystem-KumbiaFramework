<?php
	class Usuariosencuestas extends ActiveRecord {
		
	}
?>
