<?php			
	class PreseleccionTerminada extends ActiveRecord {

	}	
?>