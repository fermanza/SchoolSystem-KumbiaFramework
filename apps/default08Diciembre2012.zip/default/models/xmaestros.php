<?php
			
	class Xmaestros extends ActiveRecord {
		
	}
	
?>
