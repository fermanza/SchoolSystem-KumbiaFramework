<?php
			
	class Intersemestral extends ActiveRecord {
		
	}
	
?>
