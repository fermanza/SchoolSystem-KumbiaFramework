<?php
			
	class Evaluacion extends ActiveRecord {
		
	}
	
?>
