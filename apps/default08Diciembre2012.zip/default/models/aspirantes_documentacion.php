<?php
			
	class AspirantesDocumentacion extends ActiveRecord {
		
	}
	
?>