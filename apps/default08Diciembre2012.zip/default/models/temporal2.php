<?php
			
	class Temporal2 extends ActiveRecord {
		
	}
	
?>
