<?php
	class Xalumnocursosbt extends ActiveRecord {
		
		
		
	}
?>