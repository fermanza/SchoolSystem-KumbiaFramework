<?php
	class Xtalumnocursos extends ActiveRecord {
		
		function get_materias_semestre_actual($registro){
			$Periodos = new Periodos();
			$periodo = $Periodos->get_periodo_actual();
			
			$xalumnocursos = Array();
			foreach( $this->find_all_by_sql("
					select xal.*, xcc.clavecurso curso, xcc.clavecurso
					from xtalumnocursos xal
					inner join xtcursos xcc
					on xal.curso_id = xcc.id
					and xal.registro = '".$registro."'
					and xal.periodo = '".$periodo."'") as $xal ){
				array_push($xalumnocursos, $xal);
			}
			return $xalumnocursos;
		} // function get_materias_semestre_actual($registro)
		
		function get_materias_semestre_by_periodo($registro, $periodo){
			
			$xalumnocursos = Array();
			foreach( $this->find_all_by_sql("
					select xal.*, xcc.clavecurso curso, xcc.clavecurso
					from xtalumnocursos xal
					inner join xtcursos xcc
					on xal.curso_id = xcc.id
					and xal.registro = '".$registro."'
					and xal.periodo = '".$periodo."'") as $xal ){
				array_push($xalumnocursos, $xal);
			}
			return $xalumnocursos;
		} // function get_materias_semestre_by_periodo($registro, $periodo)
		
		function get_materia_con_baja_definitiva($registro){
			$Periodos = new Periodos();
			$periodo = $Periodos -> get_periodo_actual_();
			if( $this -> find_first("situacion = 'BAJA DEFINITIVA'".
					" and periodo = '".$periodo."'".
					" and registro = '".$registro."'") )
				return true;
			else
				return false;
		} // function get_materia_con_baja_definitiva($registro)
		
		function get_materia_con_baja_definitiva_by_periodo($registro, $periodo){
			if( $this -> find_first("situacion = 'BAJA DEFINITIVA'".
					" and periodo = '".$periodo."'".
					" and registro = '".$registro."'") )
				return true;
			else
				return false;
		} // function get_materia_con_baja_definitiva_by_periodo($registro, $periodo)
		
		function get_materias_con_baja_definitiva_o_titulo_colomos($registro){
			$Periodos = new Periodos();
			$periodo = $Periodos -> get_periodo_actual_();
			$MateriasConBajaOTitulo = Array();
			foreach( $this -> find_all_by_sql("
					select xal.*
					from xtalumnocursos xal
					where periodo = '".$periodo."'
					and registro = '".$registro."'
					and situacion = 'BAJA DEFINITIVA'") as $xal ){
				foreach( $this -> find_all_by_sql("
						select xcc.materia, m.nombre nombre_materia
						from xtcursos xcc
						inner join materia m
						on xcc.materia = m.clave
						and xcc.clavecurso = '".$xal -> curso."'
						group by xcc.id") as $xcc ){
					$BajasYTitulos -> materia = $xcc -> materia;
					$BajasYTitulos -> nombre_materia = $xcc -> nombre_materia;
					$BajasYTitulos -> calificacion = $xal -> calificacion;
					$BajasYTitulos -> situacion = $xal -> situacion;
					echo $BajasYTitulos -> clavecurso = $xal -> curso;
					array_push($MateriasConBajaOTitulo, $BajasYTitulos);
				}
			}
			foreach( $this -> find_all_by_sql("
					select xal.*
					from xtextraordinarios xal
					where periodo = '".$periodo."'
					and registro = '".$registro."'
					and tipo = 'T'
					and calificacion < 70") as $xal ){
				foreach( $this -> find_all_by_sql("
						select xcc.materia, m.nombre nombre_materia
						from xtcursos xcc
						inner join materia m
						on xcc.materia = m.clave
						and xcc.clavecurso = '".$xal -> curso."'
						group by xcc.id") as $xcc ){
					$BajasYTitulos -> materia = $xcc -> materia;
					$BajasYTitulos -> nombre_materia = $xcc -> nombre_materia;
					$BajasYTitulos -> calificacion = $xal -> calificacion;
					$BajasYTitulos -> situacion = $xal -> situacion;
					echo $BajasYTitulos -> clavecurso = $xal -> curso;
					array_push($MateriasConBajaOTitulo, $BajasYTitulos);
				}
			}
			return $MateriasConBajaOTitulo;
		} // function get_materias_con_baja_definitiva_o_titulo_colomos($registro)
		
		function get_materias_con_baja_definitiva_o_titulo_tonala($registro){
			$Periodos = new Periodos();
			$periodo = $Periodos -> get_periodo_actual_();
			$MateriasConBajaOTitulo = Array();
			foreach( $this -> find_all_by_sql("
					select xal.*
					from xtalumnocursos xal
					where periodo = '".$periodo."'
					and registro = '".$registro."'
					and situacion = 'BAJA DEFINITIVA'") as $xal ){
				foreach( $this -> find_all_by_sql("
						select xcc.materia, m.nombre nombre_materia
						from xtcursos xcc
						inner join materia m
						on xcc.materia = m.clave
						and xcc.clavecurso = '".$xal -> curso."'
						group by xcc.id") as $xcc ){
					$BajasYTitulos -> materia = $xcc -> materia;
					$BajasYTitulos -> nombre_materia = $xcc -> nombre_materia;
					$BajasYTitulos -> calificacion = $xal -> calificacion;
					$BajasYTitulos -> situacion = $xal -> situacion;
					echo $BajasYTitulos -> clavecurso = $xal -> curso;
					array_push($MateriasConBajaOTitulo, $BajasYTitulos);
				}
			}
			foreach( $this -> find_all_by_sql("
					select xal.*
					from xtextraordinarios xal
					where periodo = '".$periodo."'
					and registro = '".$registro."'
					and tipo = 'T'
					and calificacion < 70") as $xal ){
				foreach( $this -> find_all_by_sql("
						select xcc.materia, m.nombre nombre_materia
						from xtcursos xcc
						inner join materia m
						on xcc.materia = m.clave
						and xcc.clavecurso = '".$xal -> curso."'
						group by xcc.id") as $xcc ){
					$BajasYTitulos -> materia = $xcc -> materia;
					$BajasYTitulos -> nombre_materia = $xcc -> nombre_materia;
					$BajasYTitulos -> calificacion = $xal -> calificacion;
					$BajasYTitulos -> situacion = $xal -> situacion;
					echo $BajasYTitulos -> clavecurso = $xal -> curso;
					array_push($MateriasConBajaOTitulo, $BajasYTitulos);
				}
			}
			return $MateriasConBajaOTitulo;
		} // function get_materias_con_baja_definitiva_o_titulo_tonala($registro)
		
		function borrado_logico_materias_by_periodo($registro, $periodo){
			$who = Session::get_data('registro');
			$Periodos = new Periodos();
			$timestamp = $Periodos->get_datetime();
			foreach($this->find_all_by_sql("
				update xtalumnocursos
				set activo = '0',
				who = '".$who."',
				last_modified = '".$$timestamp."'
				where registro = '".$registro."'
				and periodo = '".$periodo."'") as $alumno){
					break;
			}
		} // function borrado_logico_materias_by_periodo($registro, $periodo)
		
		function activar_materias_by_periodo($registro, $periodo){
			$who = Session::get_data('registro');
			$Periodos = new Periodos();
			$timestamp = $Periodos->get_datetime();
			foreach($this->find_all_by_sql("
				update xtalumnocursos
				set activo = '1',
				who = '".$who."',
				last_modified = '".$$timestamp."'
				where registro = '".$registro."'
				and periodo = '".$periodo."'") as $alumno){
					break;
			}
		} // function activar_materias_by_periodo($registro, $periodo)
		
		function pasar_materias_a_xalumnocursosbt_by_periodo_registro($registro, $periodo){
			
			$Periodos = new Periodos();
			$periodo = $Periodos->get_periodo_actual();
			foreach($this->find_all_by_sql("
					select * from xtalumnocursos
					where registro = '".$registro."'
					and periodo = '".$periodo."'") as $xalumnocursos){
					
				$Xalumnocursosbt = new Xtalumnocursosbt();
				$Xalumnocursosbt->id_xc = $xalumnocursos->id;
				$Xalumnocursosbt->periodo = $xalumnocursos->periodo;
				$Xalumnocursosbt->curso_id = $xalumnocursos->curso_id;
				$Xalumnocursosbt->registro = $xalumnocursos->registro;
				$Xalumnocursosbt->faltas1 = $xalumnocursos->faltas1;
				$Xalumnocursosbt->calificacion1 = $xalumnocursos->calificacion1;
				$Xalumnocursosbt->faltas2 = $xalumnocursos->faltas;
				$Xalumnocursosbt->calificacion2 = $xalumnocursos->calificacion2;
				$Xalumnocursosbt->faltas3 = $xalumnocursos->faltas3;
				$Xalumnocursosbt->calificacion3 = $xalumnocursos->calificacion3;
				$Xalumnocursosbt->faltas = $xalumnocursos->faltas;
				$Xalumnocursosbt->calificacion = $xalumnocursos->calificacion;
				$Xalumnocursosbt->situacion = $xalumnocursos->situacion;
				$Xalumnocursosbt->tipo = $xalumnocursos->tipo;
				
				if( $Xalumnocursosbt->tipo == null || $Xalumnocursosbt->tipo == ""){
					$Xalumnocursosbt->tipo = "-";
				}
				$Xalumnocursosbt->create();
				
				$xalumnocursos->delete();
			}
		} // function pasar_materias_a_xalumnocursosbt_by_periodo_registro($registro, $periodo)
		
		function get_horas_cruces_de_materias($registro, $periodo){
			$ocupado = 0;
			unset($horas);
			$Xthorascursos = new Xthorascursos();
			foreach( $this -> find( "registro = ".$registro." and periodo = ".$periodo ) as $xalumnocurso ){
				foreach( $Xthorascursos -> find( "curso_id = '".
						$xalumnocurso -> curso_id."' ORDER BY id ASC" ) as $xchorascurso ){
					
					if(isset($horas[$xchorascurso->dia][$xchorascurso->hora])){
						$ocupado++;
					}
					else{
						$horas[$xchorascurso->dia][$xchorascurso->hora] = 1;
					}
				}
			}
			return $ocupado;
		} // get_horas_cruces_de_materias($registro, $periodo)
	}
?>