<?php			
	class LogCaja extends ActiveRecord {

	}	
?>