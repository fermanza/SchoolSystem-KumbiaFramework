<?php			
	class pagosreferencia extends ActiveRecord {	
	
	
	}	
?>