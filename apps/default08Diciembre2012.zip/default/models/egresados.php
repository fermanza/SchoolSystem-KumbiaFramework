<?php
			
	class Egresados extends ActiveRecord {
		
	}
	
?>
