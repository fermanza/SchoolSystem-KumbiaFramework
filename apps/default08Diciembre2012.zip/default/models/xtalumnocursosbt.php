<?php
	class Xtalumnocursosbt extends ActiveRecord {
		
		
	}
?>