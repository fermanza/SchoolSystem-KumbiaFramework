<?php
			
	class Xtextraordinarios extends ActiveRecord {
		
	}
	
?>
