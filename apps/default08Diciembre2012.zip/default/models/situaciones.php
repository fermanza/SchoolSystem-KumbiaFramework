<?php			
	class Situaciones extends ActiveRecord {

	}	
?>