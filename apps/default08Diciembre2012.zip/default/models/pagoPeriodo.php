<?php			
	class pagoperiodo extends ActiveRecord {	
	
	
	}	
?>