<?php
			
	class derechopasante extends ActiveRecord {
		
	}
	
?>
