<?php
			
	class Califing extends ActiveRecord {
		
	}
	
?>
