<?php
			
	class DacEncuestaRespuesta extends ActiveRecord {
		
	}
	
?>