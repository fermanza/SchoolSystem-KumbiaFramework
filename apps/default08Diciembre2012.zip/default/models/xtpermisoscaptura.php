<?php
			
	class Xtpermisoscaptura extends ActiveRecord {
		
	}
	
?>
