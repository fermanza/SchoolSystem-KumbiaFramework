<?php
			
	class Precursoalumno extends ActiveRecord {
		
	}
	
?>
