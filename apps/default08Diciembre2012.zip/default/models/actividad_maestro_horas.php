<?php
			
	class actividadMaestroHoras extends ActiveRecord {
		
	}
	
?>