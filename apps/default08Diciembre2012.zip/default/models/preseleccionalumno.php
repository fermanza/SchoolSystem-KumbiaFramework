<?php
			
	class Preseleccionalumno extends ActiveRecord {
		
	}
	
?>
