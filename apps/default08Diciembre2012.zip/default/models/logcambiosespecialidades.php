<?php
			
	class Logcambiosespecialidades extends ActiveRecord {
		
	}
	
?>
