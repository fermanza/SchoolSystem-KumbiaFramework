<?php
			
	class Carrerasdisp extends ActiveRecord {
		
	}
	
?>
