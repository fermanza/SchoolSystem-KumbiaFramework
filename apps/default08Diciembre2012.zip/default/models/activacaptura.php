<?php
			
	class Activacaptura extends ActiveRecord {
		
	}
	
?>
