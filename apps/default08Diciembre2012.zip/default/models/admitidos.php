<?php
			
	class Admitidos extends ActiveRecord {
		
	}
	
?>
