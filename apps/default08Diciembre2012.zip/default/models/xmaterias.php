<?php
			
	class Xmaterias extends ActiveRecord {
		
	}
	
?>
