<?php
			
	class Planmateria extends ActiveRecord {
		
	}
	
?>
