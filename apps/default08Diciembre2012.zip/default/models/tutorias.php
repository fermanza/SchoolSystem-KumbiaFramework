<?php
			
	class Tutorias extends ActiveRecord {
		
	}
	
?>
