<?php
			
	class Codexttit extends ActiveRecord {
		
	}
	
?>
