<?php			
	class Preregistros extends ActiveRecord {

	}	
?>