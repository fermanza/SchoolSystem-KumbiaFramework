<?php
			
	class Materiasespecializantes extends ActiveRecord {
		
	}
	
?>
