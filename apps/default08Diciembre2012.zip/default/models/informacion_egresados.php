<?php			
	class informacionEgresados extends ActiveRecord {

	}	
?>