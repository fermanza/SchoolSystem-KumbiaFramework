<?php
			
	class Xpermisos extends ActiveRecord {
		
	}
	
?>
