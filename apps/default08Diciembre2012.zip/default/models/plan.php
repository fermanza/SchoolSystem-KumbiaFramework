<?php
			
	class Plan extends ActiveRecord {
		
	}
	
?>
