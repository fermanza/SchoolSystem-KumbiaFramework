<?php
			
	class SeleccionTiempo extends ActiveRecord {
		
	}
	
?>
