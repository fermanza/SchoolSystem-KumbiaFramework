<?php
			
	class Curso extends ActiveRecord {
		
	}
	
?>
