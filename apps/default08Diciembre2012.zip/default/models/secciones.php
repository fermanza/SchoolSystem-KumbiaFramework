<?php
	class Secciones extends ActiveRecord {

	}
?>
