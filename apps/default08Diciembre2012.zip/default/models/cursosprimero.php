<?php
			
	class Cursosprimero extends ActiveRecord {
		
	}
	
?>
